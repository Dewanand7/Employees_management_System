<?php 

$conn = mysqli_connect( 'localhost', 'root', '', 'demo' );

if( !$conn ){
    die( 'Unable to connect' );
}

?>